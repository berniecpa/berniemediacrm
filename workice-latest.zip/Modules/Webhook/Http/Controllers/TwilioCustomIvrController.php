<?php

namespace Modules\Webhook\Http\Controllers;

use Modules\Webhook\Http\Controllers\Base\TwilioIvrController;

/**
 * This is a sample class on how to implement IVR using Twilio
 */
class TwilioCustomIvrController extends TwilioIvrController
{
}
