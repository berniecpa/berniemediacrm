<?php

namespace Modules\Webhook\Http\Controllers;

use Modules\Webhook\Http\Controllers\Base\WebhookController;

class WebhookCustomController extends WebhookController
{
    //
}
