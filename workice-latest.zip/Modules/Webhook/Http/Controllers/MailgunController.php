<?php

namespace Modules\Webhook\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class MailgunController extends Controller
{
    public function inbound(Request $request)
    {
    }
}
