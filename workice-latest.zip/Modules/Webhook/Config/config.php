<?php

return [
    'name' => 'Webhook'
];
