<?php

namespace Modules\Calendar\Http\Controllers;

use App\Http\Controllers\Controller;
use Modules\Calendar\Http\Controllers\Base\CalendarController;

class CalendarCustomController extends CalendarController
{
}
