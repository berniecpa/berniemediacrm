<?php

namespace Modules\Timetracking\Http\Controllers;

use Modules\Timetracking\Http\Controllers\Base\TimerController;

class TimerCustomController extends TimerController
{
    //
}
