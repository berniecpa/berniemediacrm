<?php

namespace Modules\Todos\Http\Controllers;

use Modules\Todos\Http\Controllers\Base\TodoController;

class TodoCustomController extends TodoController
{
    //
}
