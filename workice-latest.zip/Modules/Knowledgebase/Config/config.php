<?php

return [
    'name' => 'Knowledgebase'
];
