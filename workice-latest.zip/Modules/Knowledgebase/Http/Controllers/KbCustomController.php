<?php

namespace Modules\Knowledgebase\Http\Controllers;

use Modules\Knowledgebase\Http\Controllers\Base\KbController;

class KbCustomController extends KbController
{
    //
}
