<?php

namespace Modules\Milestones\Http\Controllers;

use Modules\Milestones\Http\Controllers\Base\MilestonesController;

class MilestoneCustomController extends MilestonesController
{
    //
}
