<?php

namespace Modules\Creditnotes\Http\Controllers;

use Modules\Creditnotes\Http\Controllers\Base\CreditnotesController;

class CreditCustomController extends CreditnotesController
{
    //
}
