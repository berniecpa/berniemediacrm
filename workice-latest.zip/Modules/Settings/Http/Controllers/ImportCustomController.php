<?php

namespace Modules\Settings\Http\Controllers;

use Modules\Settings\Http\Controllers\Base\ImportController;

class ImportCustomController extends ImportController
{
}
