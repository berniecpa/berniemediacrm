<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Messages\\Providers\\MessagesServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Messages\\Providers\\MessagesServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);