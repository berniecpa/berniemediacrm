<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Leads\\Providers\\LeadsServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Leads\\Providers\\LeadsServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);