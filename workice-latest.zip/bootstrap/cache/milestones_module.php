<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Milestones\\Providers\\MilestonesServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Milestones\\Providers\\MilestonesServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);