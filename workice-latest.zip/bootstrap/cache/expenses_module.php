<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Expenses\\Providers\\ExpensesServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Expenses\\Providers\\ExpensesServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);