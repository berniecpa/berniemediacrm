<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Activity\\Providers\\ActivityServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Activity\\Providers\\ActivityServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);