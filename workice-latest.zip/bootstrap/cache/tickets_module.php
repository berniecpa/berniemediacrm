<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Tickets\\Providers\\TicketsServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Tickets\\Providers\\TicketsServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);