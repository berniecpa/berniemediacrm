<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Tasks\\Providers\\TasksServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Tasks\\Providers\\TasksServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);