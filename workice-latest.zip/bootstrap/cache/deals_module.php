<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Deals\\Providers\\DealsServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Deals\\Providers\\DealsServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);