<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Updates\\Providers\\UpdatesServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Updates\\Providers\\UpdatesServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);