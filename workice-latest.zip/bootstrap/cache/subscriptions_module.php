<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Subscriptions\\Providers\\SubscriptionsServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Subscriptions\\Providers\\SubscriptionsServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);