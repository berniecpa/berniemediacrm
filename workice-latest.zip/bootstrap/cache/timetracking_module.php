<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Timetracking\\Providers\\TimetrackingServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Timetracking\\Providers\\TimetrackingServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);