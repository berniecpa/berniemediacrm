<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Estimates\\Providers\\EstimatesServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Estimates\\Providers\\EstimatesServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);