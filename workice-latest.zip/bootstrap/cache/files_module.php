<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Files\\Providers\\FilesServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Files\\Providers\\FilesServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);