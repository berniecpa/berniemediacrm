<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Knowledgebase\\Providers\\KnowledgebaseServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Knowledgebase\\Providers\\KnowledgebaseServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);