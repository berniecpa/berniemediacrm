<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Contracts\\Providers\\ContractsServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Contracts\\Providers\\ContractsServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);