<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Issues\\Providers\\IssuesServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Issues\\Providers\\IssuesServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);