<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Todos\\Providers\\TodosServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Todos\\Providers\\TodosServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);