<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Comments\\Providers\\CommentsServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Comments\\Providers\\CommentsServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);