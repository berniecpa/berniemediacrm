<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Webhook\\Providers\\WebhookServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Webhook\\Providers\\WebhookServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);