<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Creditnotes\\Providers\\CreditnotesServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Creditnotes\\Providers\\CreditnotesServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);