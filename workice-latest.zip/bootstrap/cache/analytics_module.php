<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Analytics\\Providers\\AnalyticsServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Analytics\\Providers\\AnalyticsServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);