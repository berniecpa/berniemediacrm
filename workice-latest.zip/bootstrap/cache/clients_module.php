<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Clients\\Providers\\ClientsServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Clients\\Providers\\ClientsServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);