<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Extras\\Providers\\ExtrasServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Extras\\Providers\\ExtrasServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);