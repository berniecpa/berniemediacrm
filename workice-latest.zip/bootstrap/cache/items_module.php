<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Items\\Providers\\ItemsServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Items\\Providers\\ItemsServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);