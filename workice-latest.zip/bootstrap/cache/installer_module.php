<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Installer\\Providers\\InstallerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Installer\\Providers\\InstallerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);