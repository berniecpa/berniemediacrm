<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Calendar\\Providers\\CalendarServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Calendar\\Providers\\CalendarServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);